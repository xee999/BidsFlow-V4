# Project Plan: BidsFlow Enterprise Hardening & ISG Compliance

**Version:** 1.0  
**Date:** February 13, 2026  
**Subject:** Technical Implementation Roadmap for ISG Approval  

---

## 1. Executive Summary
Following the security review by the Information Security Governance (ISG) team, the BidsFlow platform has been granted "Conditional Acceptance" subject to the implementation of enterprise-grade security controls. This document outlines the technical workstreams required to mitigate residual risks from "Medium-High" to an acceptable "Medium" level for production go-live on the Garaj platform.

---

## 2. Technical Workstreams

### Workstream 1: Identity & Access Management (IAM)
*Objective: Eliminate tenant-wide exposure and harden service accounts.*

| ID | Task | Implementation Detail |
| :--- | :--- | :--- |
| **IAM-01** | **Exchange App Access Policy** | Implement `New-ApplicationAccessPolicy` to restrict the Azure AD App ID specifically to the `bids@jazz.com.pk` mailbox. |
| **IAM-02** | **Conditional Access (CA)** | Restrict `svc-bidsflow@jazz.com.pk` to Jazz Corporate Network IP ranges via Azure AD CA policies. |
| **IAM-03** | **OAuth Token Life-cycle** | Configure refresh token rotation and set TTL (Time-to-Live) limits to prevent persistent session risks. |

### Workstream 2: Application Development (Security-by-Design)
*Objective: Implement Proactive DLP and Secrets Management.*

| ID | Task | Implementation Detail |
| :--- | :--- | :--- |
| **APP-01** | **Azure Key Vault Integration** | Terminate use of local `.env` or config files for secrets. Implement runtime fetching from **Azure Key Vault** using Managed Identities. |
| **APP-02** | **Dynamic PDF Watermarking** | Integrate server-side watermarking (using `pdf-lib`) to stamp all downloaded documents with User identity and Date. |
| **APP-03** | **FortiSIEM Log Export** | Configure application-level audit logs to export in JSON format to Garaj's centralized **FortiSIEM** collector. |
| **APP-04** | **Enhanced Session Control** | Enforce 30-minute absolute session timeouts and browser-level inactivity locking. |

### Workstream 3: Infrastructure & Operations
*Objective: Harden the Garaj hosting environment.*

| ID | Task | Implementation Detail |
| :--- | :--- | :--- |
| **INF-01** | **EDR Deployment** | Install Jazz-standard **Endpoint Detection & Response (EDR)** agents on all production nodes. |
| **INF-02** | **Net-Segment & Firewall** | Implement strict egress (outbound) rules via NSGs to whitelist only Graph API, ServiceNow, and OpenAI endpoints. |
| **INF-03** | **Patch & Vulnerability Mgmt** | Enroll nodes in the Jazz vulnerability scanning program with defined Remediation SLAs. |

---

## 3. Revised Security Architecture
The updated architecture moves from an "Open Trust" model to a **"Zero Trust"** framework:

1.  **Identity Layer:** Every API call to Outlook is checked against the *Application Access Policy*.
2.  **Secret Layer:** No credentials exist on the server; they are pulled from the *Secure Vault* just-in-time.
3.  **Data Layer:** Documents are processed in an *Isolated Subnet*; any export is *Watermarked* and *Logged*.
4.  **Monitoring Layer:** OS, App, and Azure AD logs are aggregated into *FortiSIEM* for real-time anomaly detection.

---

## 4. Timeline & Milestones

*   **Milestone 1 (Week 1):** Infrastructure Hardening (EDR, Firewall, Key Vault Setup).
*   **Milestone 2 (Week 2):** Feature Development (Watermarking logic, SIEM log forwarding scripts).
*   **Milestone 3 (Week 3):** Verification & Testing (Validation of "Zero-Retention" AI flow and DPA sign-off).
*   **Milestone 4 (Week 4):** Final ISG Technical Session & Production Approval.

---

## 5. Risk Assessment (Residual)
| Phase | Risk Level | Primary Controls |
| :--- | :--- | :--- |
| **Pre-Implementation** | Medium-High | Local configuration, wide identity scope. |
| **Post-Implementation** | Medium | Centralized secrets, scoped access, EDR/SIEM visibility. |

---
**Prepared by:**  
Project Management Office – BidsFlow Implementation Team 
