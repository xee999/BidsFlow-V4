
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import BidIntake from './components/BidIntake';
import BidLifecycle from './components/BidLifecycle';
import { BidRecord, BidStatus, BidStage, RiskLevel } from './types';

const INITIAL_BIDS: BidRecord[] = [
  {
    id: 'bid-1',
    customerName: 'PITB (Punjab IT Board)',
    projectName: 'Punjab Healthcare Cloud Transformation 2024',
    deadline: '2024-11-15',
    receivedDate: '2024-10-01',
    status: BidStatus.ACTIVE,
    currentStage: BidStage.SOLUTIONING,
    riskLevel: RiskLevel.MEDIUM,
    estimatedValue: 125000000,
    currency: 'PKR',
    bidSecurity: '2%',
    requiredSolutions: ['Cloud Solutions', 'IT Devices (Laptop/Desktop)', 'CPaaS'],
    summaryRequirements: 'Implementation of high-availability cloud infrastructure for public healthcare data storage and management.',
    // Added missing scopeOfWork to fix property requirement error
    scopeOfWork: 'Provision and configuration of 500+ cloud nodes, backup systems, and security protocols.',
    qualificationCriteria: 'Must have ISO 27001, previous cloud deployments in public sector (>500 nodes).',
    complianceChecklist: [],
    technicalDocuments: [],
    vendorQuotations: [],
    financialFormats: [],
    daysInStages: { [BidStage.INTAKE]: 2, [BidStage.QUALIFICATION]: 3 },
    stageHistory: [
      { stage: BidStage.INTAKE, timestamp: '2024-10-01T10:00:00Z' },
      { stage: BidStage.QUALIFICATION, timestamp: '2024-10-03T14:30:00Z' },
      { stage: BidStage.SOLUTIONING, timestamp: '2024-10-06T09:15:00Z' }
    ],
    jbcName: 'Ali Ahmed'
  },
  {
    id: 'bid-2',
    customerName: 'FBR',
    projectName: 'Customs Mobile Surveillance Units',
    deadline: '2024-11-20',
    receivedDate: '2024-10-05',
    status: BidStatus.ACTIVE,
    currentStage: BidStage.INTAKE,
    riskLevel: RiskLevel.HIGH,
    estimatedValue: 85000000,
    currency: 'PKR',
    bidSecurity: '5,000,000',
    requiredSolutions: ['GSM Data', 'M2M (Devices Only)', 'Mobile Devices (Phone or Tablet)'],
    summaryRequirements: 'Provision of mobile units equipped with GSM-based surveillance and reporting tools for real-time tracking.',
    // Added missing scopeOfWork to fix property requirement error
    scopeOfWork: 'Deployment of mobile surveillance hardware, SIM cards, and dashboard integration.',
    qualificationCriteria: 'OEM partnership for hardware, 5+ years of telecom support experience.',
    complianceChecklist: [],
    technicalDocuments: [],
    vendorQuotations: [],
    financialFormats: [],
    daysInStages: { [BidStage.INTAKE]: 1 },
    stageHistory: [
      { stage: BidStage.INTAKE, timestamp: '2024-10-05T08:45:00Z' }
    ],
    jbcName: 'Sarah Khan'
  }
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [bids, setBids] = useState<BidRecord[]>(INITIAL_BIDS);
  const [viewingBidId, setViewingBidId] = useState<string | null>(null);
  const [showIntake, setShowIntake] = useState(false);

  const handleInitiateBid = (newBid: BidRecord) => {
    setBids(prev => [newBid, ...prev]);
    setShowIntake(false);
    setViewingBidId(newBid.id);
  };

  const handleUpdateBid = (updatedBid: BidRecord) => {
    setBids(prev => prev.map(b => b.id === updatedBid.id ? updatedBid : b));
  };

  const currentBid = bids.find(b => b.id === viewingBidId);

  // If viewing a bid, the Lifecycle UI takes over full screen
  if (viewingBidId && currentBid) {
    return (
      <BidLifecycle 
        bid={currentBid} 
        onUpdate={handleUpdateBid} 
        onClose={() => setViewingBidId(null)} 
      />
    );
  }

  return (
    <div className="flex bg-gray-50 min-h-screen">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 ml-64 min-h-screen">
        {showIntake ? (
          <BidIntake onCancel={() => setShowIntake(false)} onInitiate={handleInitiateBid} />
        ) : (
          <>
            {activeTab === 'dashboard' && (
              <Dashboard 
                bids={bids} 
                onNewBid={() => setShowIntake(true)} 
                onViewBid={setViewingBidId} 
              />
            )}
            
            {activeTab === 'all-bids' && (
              <div className="p-8 max-w-7xl mx-auto">
                <div className="flex justify-between items-center mb-8">
                  <h1 className="text-3xl font-bold text-slate-900">All Bids Repository</h1>
                  <div className="flex gap-2">
                     <span className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-500 font-medium cursor-pointer hover:bg-slate-50">Filter by Stage</span>
                     <span className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-500 font-medium cursor-pointer hover:bg-slate-50">Filter by Status</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {bids.map(bid => (
                    <div 
                      key={bid.id} 
                      onClick={() => setViewingBidId(bid.id)}
                      className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all cursor-pointer group"
                    >
                      <div className="flex justify-between items-start mb-4">
                        <span className={clsx(
                          "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
                          bid.status === BidStatus.ACTIVE ? "bg-blue-50 text-blue-600" :
                          bid.status === BidStatus.SUBMITTED ? "bg-emerald-50 text-emerald-600" :
                          bid.status === BidStatus.WON ? "bg-emerald-500 text-white" : "bg-slate-100 text-slate-400"
                        )}>
                          {bid.status}
                        </span>
                        <div className="flex gap-1">
                          {bid.requiredSolutions.slice(0, 2).map(s => (
                             <div key={s} className="w-2 h-2 rounded-full bg-red-400"></div>
                          ))}
                        </div>
                      </div>
                      <h3 className="font-bold text-slate-900 group-hover:text-[#D32F2F] transition-colors line-clamp-1">{bid.projectName}</h3>
                      <p className="text-xs text-slate-400 mb-6">{bid.customerName}</p>
                      
                      <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                        <div className="text-[10px] font-bold text-slate-400 uppercase">Stage: {bid.currentStage}</div>
                        <div className="text-[10px] font-bold text-red-500 uppercase">{bid.deadline}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {activeTab === 'reports' && (
              <div className="p-8 max-w-7xl mx-auto flex flex-col items-center justify-center h-[80vh]">
                 <div className="p-10 bg-white border border-slate-200 rounded-3xl text-center space-y-4 shadow-sm">
                   <div className="w-16 h-16 bg-blue-50 text-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                   </div>
                   <h2 className="text-xl font-bold text-slate-900">Bid Performance Reports</h2>
                   <p className="text-sm text-slate-500 max-w-sm">Detailed metrics on win/loss ratios, cycle times per stage, and team efficiency will appear here.</p>
                   <button className="bg-[#1E3A5F] text-white px-6 py-2 rounded-lg text-sm font-bold">Generate Q4 Report</button>
                 </div>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
};

function clsx(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}

export default App;
