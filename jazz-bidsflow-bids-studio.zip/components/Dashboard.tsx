
import React from 'react';
import { TrendingUp, Clock, AlertCircle, ArrowUpRight, Plus } from 'lucide-react';
import { BidRecord, BidStatus } from '../types';

interface DashboardProps {
  bids: BidRecord[];
  onNewBid: () => void;
  onViewBid: (bidId: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ bids, onNewBid, onViewBid }) => {
  const activeBids = bids.filter(b => b.status === BidStatus.ACTIVE);
  const highRiskBids = activeBids.filter(b => b.riskLevel === 'High');
  
  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Bids Dashboard</h1>
          <p className="text-slate-500 mt-1">Welcome back, Jazz Bids Team</p>
        </div>
        <button 
          onClick={onNewBid}
          className="bg-[#D32F2F] hover:bg-[#B71C1C] text-white px-6 py-3 rounded-lg font-semibold flex items-center gap-2 shadow-lg transition-all"
        >
          <Plus size={20} />
          New Bid Intake
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <StatCard 
          label="Active Bids" 
          value={activeBids.length} 
          subValue="+2 from last week" 
          icon={<Clock className="text-blue-500" />} 
        />
        <StatCard 
          label="Win Rate (YTD)" 
          value="42%" 
          subValue="Target: 40%" 
          icon={<TrendingUp className="text-green-500" />} 
        />
        <StatCard 
          label="High Risk Bids" 
          value={highRiskBids.length} 
          subValue="Requires immediate attention" 
          icon={<AlertCircle className="text-red-500" />} 
          isAlert
        />
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <h2 className="text-xl font-bold text-slate-800">Active Pipeline</h2>
          <button className="text-sm text-blue-600 font-medium hover:underline">View All</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-bold">
              <tr>
                <th className="px-6 py-4">Customer & Project</th>
                <th className="px-6 py-4">Deadline</th>
                <th className="px-6 py-4">Stage</th>
                <th className="px-6 py-4">Risk</th>
                <th className="px-6 py-4">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {activeBids.map((bid) => (
                <tr key={bid.id} className="hover:bg-slate-50 transition-colors cursor-pointer" onClick={() => onViewBid(bid.id)}>
                  <td className="px-6 py-4">
                    <div className="font-semibold text-slate-900">{bid.customerName}</div>
                    <div className="text-xs text-slate-500 truncate max-w-xs">{bid.projectName}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-slate-600 font-medium">{bid.deadline}</div>
                    <div className="text-[10px] text-red-500 font-bold">12 Days Left</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-bold border border-blue-100">
                      {bid.currentStage}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={clsx(
                      "px-3 py-1 rounded-full text-xs font-bold border",
                      bid.riskLevel === 'High' ? "bg-red-50 text-red-700 border-red-100" :
                      bid.riskLevel === 'Medium' ? "bg-amber-50 text-amber-700 border-amber-100" :
                      "bg-emerald-50 text-emerald-700 border-emerald-100"
                    )}>
                      {bid.riskLevel}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-slate-400 hover:text-slate-900 transition-colors">
                      <ArrowUpRight size={20} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ label: string; value: string | number; subValue: string; icon: React.ReactNode; isAlert?: boolean }> = ({ 
  label, value, subValue, icon, isAlert 
}) => (
  <div className={clsx(
    "p-6 rounded-2xl bg-white border border-slate-200 shadow-sm",
    isAlert && "border-l-4 border-l-red-500"
  )}>
    <div className="flex justify-between items-start mb-4">
      <div className="p-3 bg-slate-50 rounded-xl">{icon}</div>
      <span className="text-xs font-bold text-slate-400 uppercase">{label}</span>
    </div>
    <div className="text-3xl font-bold text-slate-900 mb-1">{value}</div>
    <div className="text-xs text-slate-500">{subValue}</div>
  </div>
);

function clsx(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}

export default Dashboard;
