import React from 'react';
import { NAV_ITEMS, COLORS } from '../constants';
import { clsx } from 'clsx';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  return (
    <div className="w-64 h-screen bg-[#1E3A5F] text-white flex flex-col fixed left-0 top-0 z-50 shadow-2xl">
      {/* Branding Section */}
      <div className="p-8">
        <h1 className="text-3xl font-bold tracking-tight text-white flex items-center justify-center gap-2">
          Bids<span className="text-[#D32F2F]">Flow</span>
        </h1>
        <p className="text-[10px] text-slate-400 mt-2 text-center uppercase font-bold tracking-widest border-t border-white/10 pt-2">
          Jazz Business Bids Studio
        </p>
      </div>

      {/* Navigation Section */}
      <nav className="flex-1 px-4 py-4 space-y-1">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={clsx(
              "w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 text-sm font-medium",
              activeTab === item.id 
                ? "bg-[#D32F2F] text-white shadow-lg translate-x-1" 
                : "text-slate-300 hover:bg-white/10 hover:text-white hover:translate-x-1"
            )}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </nav>

      {/* Footer Branding Section */}
      <div className="p-6 border-t border-white/10 bg-[#152943]">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-[#D32F2F] flex items-center justify-center text-white font-black text-xs shadow-inner">
            BT
          </div>
          <div>
            <p className="text-sm font-bold text-white leading-tight">Bids Team</p>
            <p className="text-[10px] text-slate-400 font-medium tracking-wide">v2.4.0-pro</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;