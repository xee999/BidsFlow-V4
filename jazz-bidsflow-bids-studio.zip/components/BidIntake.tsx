import React, { useState, useRef } from 'react';
import { Upload, X, Loader2, Sparkles, CheckCircle, Info } from 'lucide-react';
import { BidRecord, BidStage, BidStatus, RiskLevel, ComplianceItem } from '../types';
import { analyzeBidDocument } from '../services/gemini';
import { SOLUTION_OPTIONS } from '../constants';

interface BidIntakeProps {
  onCancel: () => void;
  onInitiate: (bid: BidRecord) => void;
}

const BidIntake: React.FC<BidIntakeProps> = ({ onCancel, onInitiate }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [formData, setFormData] = useState<Partial<BidRecord>>({
    customerName: '',
    projectName: '',
    deadline: '',
    estimatedValue: 0,
    currency: 'PKR',
    bidSecurity: '',
    requiredSolutions: [],
    qualificationCriteria: '',
    summaryRequirements: '',
    scopeOfWork: '',
    complianceChecklist: [],
    riskLevel: RiskLevel.LOW,
    jbcName: '',
    contractDuration: '',
    customerPaymentTerms: '',
    financialFormats: []
  });
  
  const [goNoGo, setGoNoGo] = useState<'Go' | 'No-Go' | 'Needs Review'>('Needs Review');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatWithCommas = (val: string | number) => {
    const num = Number(val);
    if (isNaN(num)) return val;
    return num.toLocaleString();
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsAnalyzing(true);
    
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = (reader.result as string).split(',')[1];
      const result = await analyzeBidDocument(file.name, base64);
      
      if (result) {
        const extractedChecklist: ComplianceItem[] = (result.complianceList || []).map((item: any) => ({
          requirement: item.requirement,
          status: 'Pending',
          aiComment: item.description
        }));

        setFormData(prev => ({
          ...prev,
          customerName: result.customerName || prev.customerName,
          projectName: result.projectName || prev.projectName,
          deadline: result.deadline || prev.deadline,
          estimatedValue: Number(result.estimatedValue) || 0,
          currency: result.currency || 'PKR',
          bidSecurity: result.bidSecurity || '',
          qualificationCriteria: result.qualificationCriteria || '',
          summaryRequirements: result.summaryRequirements || '',
          scopeOfWork: result.scopeOfWork || '',
          requiredSolutions: result.requiredSolutions || [],
          complianceChecklist: extractedChecklist,
          contractDuration: result.contractDuration || '',
          customerPaymentTerms: result.customerPaymentTerms || '',
          financialFormats: result.financialFormats || []
        }));
        setGoNoGo('Go');
      }
      setIsAnalyzing(false);
    };
    reader.readAsDataURL(file);
  };

  const toggleSolution = (sol: string) => {
    setFormData(prev => ({
      ...prev,
      requiredSolutions: prev.requiredSolutions?.includes(sol)
        ? prev.requiredSolutions.filter(s => s !== sol)
        : [...(prev.requiredSolutions || []), sol]
    }));
  };

  const handleInitiate = () => {
    if (!formData.customerName || !formData.projectName) {
      alert("Please fill in key details");
      return;
    }

    const newBid: BidRecord = {
      id: Math.random().toString(36).substr(2, 9),
      customerName: formData.customerName!,
      projectName: formData.projectName!,
      deadline: formData.deadline || new Date().toISOString().split('T')[0],
      receivedDate: new Date().toISOString().split('T')[0],
      status: BidStatus.ACTIVE,
      currentStage: BidStage.QUALIFICATION,
      riskLevel: formData.riskLevel || RiskLevel.LOW,
      estimatedValue: Number(formData.estimatedValue) || 0,
      currency: formData.currency || 'PKR',
      bidSecurity: formData.bidSecurity || '',
      requiredSolutions: formData.requiredSolutions || [],
      summaryRequirements: formData.summaryRequirements || '',
      scopeOfWork: formData.scopeOfWork || '',
      qualificationCriteria: formData.qualificationCriteria || '',
      complianceChecklist: formData.complianceChecklist || [],
      technicalDocuments: [],
      vendorQuotations: [],
      financialFormats: formData.financialFormats || [],
      daysInStages: { [BidStage.INTAKE]: 1 },
      stageHistory: [{ stage: BidStage.INTAKE, timestamp: new Date().toISOString() }],
      jbcName: formData.jbcName || 'John Doe',
      contractDuration: formData.contractDuration,
      customerPaymentTerms: formData.customerPaymentTerms,
      managementApprovalStatus: 'Pending'
    };

    onInitiate(newBid);
  };

  return (
    <div className="p-8 max-w-6xl mx-auto bg-white rounded-3xl shadow-xl border border-slate-200 mt-10 mb-20 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center mb-8 pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">New Bid Intake</h2>
          <p className="text-slate-500">AI-Powered Tender Analysis & Qualification</p>
        </div>
        <button onClick={onCancel} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
          <X size={24} className="text-slate-400" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-6">
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-200 rounded-2xl p-10 text-center hover:border-[#D32F2F] hover:bg-red-50/30 transition-all cursor-pointer group"
          >
            <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept=".pdf" />
            {isAnalyzing ? (
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="animate-spin text-[#D32F2F]" size={40} />
                <p className="font-semibold text-slate-700">AI Analyzing Document...</p>
                <p className="text-xs text-slate-400">Extracting deadline, SOW, duration & payment terms</p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3">
                <div className="p-4 bg-red-50 rounded-full group-hover:scale-110 transition-transform">
                  <Upload className="text-[#D32F2F]" size={32} />
                </div>
                <p className="font-semibold text-slate-700">Upload Tender Document (PDF)</p>
                <p className="text-xs text-slate-400">AI will auto-populate fields and pre-select solutions</p>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField label="Customer Name" value={formData.customerName} onChange={v => setFormData({...formData, customerName: v})} />
            <InputField label="Project Name" value={formData.projectName} onChange={v => setFormData({...formData, projectName: v})} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <InputField label="Submission Deadline" type="date" value={formData.deadline} onChange={v => setFormData({...formData, deadline: v})} />
            <InputField label="Contract Duration" value={formData.contractDuration} onChange={v => setFormData({...formData, contractDuration: v})} placeholder="e.g. 2 Years" />
            <div className="relative">
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Payment Terms</label>
              <div className="flex items-center bg-slate-50 border border-slate-200 rounded-xl px-4 overflow-hidden">
                <input 
                  type="text" 
                  value={formData.customerPaymentTerms} 
                  onChange={e => setFormData({...formData, customerPaymentTerms: e.target.value})} 
                  className="w-full bg-transparent py-3 text-sm focus:outline-none"
                  placeholder="45"
                />
                <span className="text-xs font-bold text-slate-400">Days</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex-1">
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Estimated Bid Value</label>
              <div className="relative">
                <input 
                  type="text" 
                  value={formatWithCommas(formData.estimatedValue || '')} 
                  onChange={e => {
                    const val = e.target.value.replace(/,/g, '');
                    if (!isNaN(Number(val))) setFormData({...formData, estimatedValue: Number(val)});
                  }} 
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#D32F2F] focus:outline-none font-mono"
                  placeholder="0.00"
                />
              </div>
            </div>
            <InputField label="Currency" value={formData.currency} onChange={v => setFormData({...formData, currency: v})} />
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Bid Security</label>
              <input 
                type="text" 
                value={formData.bidSecurity} 
                onChange={e => setFormData({...formData, bidSecurity: e.target.value})} 
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#D32F2F] focus:outline-none font-mono"
                placeholder="2% or Amount"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Project Summary</label>
              <textarea 
                value={formData.summaryRequirements}
                onChange={e => setFormData({...formData, summaryRequirements: e.target.value})}
                rows={3}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#D32F2F] focus:outline-none"
                placeholder="High-level project overview..."
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Scope of Work</label>
              <textarea 
                value={formData.scopeOfWork}
                onChange={e => setFormData({...formData, scopeOfWork: e.target.value})}
                rows={4}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#D32F2F] focus:outline-none"
                placeholder="Detailed technical deliverables..."
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-3">Required Solutions</label>
            <div className="flex flex-wrap gap-2">
              {SOLUTION_OPTIONS.map(sol => (
                <button
                  key={sol}
                  onClick={() => toggleSolution(sol)}
                  className={`px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-wider transition-all border ${
                    formData.requiredSolutions?.includes(sol)
                      ? "bg-[#D32F2F] text-white border-[#D32F2F] shadow-lg scale-105"
                      : "bg-white text-slate-600 border-slate-200 hover:border-slate-400"
                  }`}
                >
                  {sol}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-8 bg-slate-50 p-6 rounded-3xl border border-slate-100 flex flex-col">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="text-[#D32F2F]" size={20} />
              <h3 className="font-bold text-slate-800">AI Qualification Criteria</h3>
            </div>
            <textarea 
              value={formData.qualificationCriteria}
              onChange={e => setFormData({...formData, qualificationCriteria: e.target.value})}
              rows={8}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#D32F2F] focus:outline-none leading-relaxed"
              placeholder="AI extracted mandatory eligibility criteria..."
            />
          </div>

          <div className="pt-4 space-y-3">
            <button 
              onClick={handleInitiate}
              className="w-full bg-[#D32F2F] text-white py-4 rounded-xl font-bold shadow-lg shadow-red-100 hover:bg-[#B71C1C] transition-all transform active:scale-95"
            >
              Initiate Bid Process
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const InputField: React.FC<{ label: string; value?: string | number; onChange: (v: string) => void; type?: string; placeholder?: string }> = ({ label, value, onChange, type = "text", placeholder }) => (
  <div>
    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">{label}</label>
    <input 
      type={type} 
      value={value} 
      onChange={e => onChange(e.target.value)} 
      placeholder={placeholder}
      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#D32F2F] focus:outline-none"
    />
  </div>
);

export default BidIntake;