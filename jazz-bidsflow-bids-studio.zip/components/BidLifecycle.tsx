import React, { useState, useRef } from 'react';
import { 
  ArrowLeft, 
  ChevronRight, 
  ChevronLeft, 
  ShieldAlert, 
  FileUp, 
  Zap, 
  Info,
  CheckCircle2,
  Loader2,
  FileText,
  ShieldCheck,
  CheckSquare,
  CreditCard,
  UserCheck,
  Clock,
  AlertTriangle,
  Sparkles,
  XCircle,
  Download
} from 'lucide-react';
import { BidRecord, BidStage, BidStatus, TechnicalDocument, StageTransition, ComplianceItem } from '../types';
import { STAGE_ICONS } from '../constants';
import { compareTechnicalSolution, analyzePricingDocument, analyzeComplianceDocuments } from '../services/gemini';
import FloatingAIChat from './FloatingAIChat';

interface BidLifecycleProps {
  bid: BidRecord;
  onUpdate: (updatedBid: BidRecord) => void;
  onClose: () => void;
}

const BidLifecycle: React.FC<BidLifecycleProps> = ({ bid, onUpdate, onClose }) => {
  const [activeStage, setActiveStage] = useState<BidStage>(bid.currentStage);
  const [showNoBidModal, setShowNoBidModal] = useState(false);
  const [noBidReason, setNoBidReason] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  const technicalFileInputRef = useRef<HTMLInputElement>(null);
  const pricingFileInputRef = useRef<HTMLInputElement>(null);
  const complianceFileInputRef = useRef<HTMLInputElement>(null);

  const stagesOrder = [
    BidStage.INTAKE,
    BidStage.QUALIFICATION,
    BidStage.SOLUTIONING,
    BidStage.PRICING,
    BidStage.COMPLIANCE,
    BidStage.FINAL_REVIEW
  ];

  const currentStageIndex = stagesOrder.indexOf(activeStage);

  const getRemainingDays = () => {
    const deadlineStr = bid.deadline;
    if (!deadlineStr) return 0;
    const deadline = new Date(deadlineStr);
    const today = new Date();
    today.setHours(0,0,0,0);
    deadline.setHours(0,0,0,0);
    const diffTime = deadline.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const remainingDays = getRemainingDays();

  const handleStageChange = (targetStage: BidStage) => {
    const newHistory: StageTransition[] = [
      ...(bid.stageHistory || []),
      { stage: targetStage, timestamp: new Date().toISOString() }
    ];
    
    onUpdate({ 
      ...bid, 
      currentStage: targetStage,
      stageHistory: newHistory
    });
    setActiveStage(targetStage);
  };

  const moveStage = (dir: 1 | -1) => {
    const next = stagesOrder[currentStageIndex + dir];
    if (next) {
      handleStageChange(next);
    }
  };

  const toggleComplianceStatus = (index: number) => {
    const updatedChecklist = bid.complianceChecklist.map((item, i) => 
      i === index 
        ? { ...item, status: item.status === 'Verified' ? 'Pending' : 'Verified' } as ComplianceItem 
        : item
    );
    onUpdate({ ...bid, complianceChecklist: updatedChecklist });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, category: 'Technical' | 'Compliance' | 'Financial') => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsAnalyzing(true);
    
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = (reader.result as string).split(',')[1];
      
      if (category === 'Technical') {
        const result = await compareTechnicalSolution(bid.qualificationCriteria || bid.summaryRequirements, base64);
        if (result) {
          const newDoc: TechnicalDocument = {
            id: Math.random().toString(36).substr(2, 9),
            name: file.name,
            type: 'Technical Proposal',
            category: 'Technical',
            uploadDate: new Date().toLocaleDateString(),
            aiScore: result.aiScore,
            aiMatchDetails: `${result.matchDetails} ${result.lackingDetails ? '\n\nLacking: ' + result.lackingDetails : ''}`,
            vendorName: result.vendorName,
            validity: result.validity,
            currency: (result.currency as any) || 'PKR',
            paymentTerms: result.paymentTerms
          };
          onUpdate({ ...bid, technicalDocuments: [...bid.technicalDocuments, newDoc] });
        }
      } else if (category === 'Financial') {
        const result = await analyzePricingDocument(base64, bid.contractDuration || "12 months", bid.financialFormats || []);
        if (result) {
          const newDoc: TechnicalDocument = {
            id: Math.random().toString(36).substr(2, 9),
            name: file.name,
            type: 'Pricing Proposal',
            category: 'Financial',
            uploadDate: new Date().toLocaleDateString()
          };
          
          onUpdate({ 
            ...bid, 
            technicalDocuments: [...bid.technicalDocuments, newDoc],
            tcvExclTax: result.tcvExclTax,
            tcvInclTax: result.tcvInclTax,
            financialFormats: bid.financialFormats.map(f => {
              const matched = result.populatedFinancialFormat.find((pf: any) => pf.item === f.item);
              return matched ? { ...f, unitPrice: matched.unitPrice, totalPrice: matched.totalPrice } : f;
            })
          });
        }
      } else if (category === 'Compliance') {
        const result = await analyzeComplianceDocuments(bid.qualificationCriteria || bid.summaryRequirements, bid.complianceChecklist, base64);
        if (result) {
          const newDoc: TechnicalDocument = {
            id: Math.random().toString(36).substr(2, 9),
            name: file.name,
            type: 'Compliance Document',
            category: 'Compliance',
            uploadDate: new Date().toLocaleDateString()
          };
          onUpdate({ 
            ...bid, 
            technicalDocuments: [...bid.technicalDocuments, newDoc],
            complianceChecklist: result.updatedChecklist || bid.complianceChecklist,
            aiQualificationAssessment: result.assessment,
            qualifyingFactors: result.qualifyingFactors,
            disqualifyingFactors: result.disqualifyingFactors,
            aiConfidenceScore: result.confidenceScore
          });
        }
      }
      setIsAnalyzing(false);
      if (e.target) e.target.value = "";
    };
    reader.readAsDataURL(file);
  };

  const markNoBid = () => {
    onUpdate({ 
      ...bid, 
      status: BidStatus.NO_BID, 
      noBidReason, 
      noBidStage: activeStage 
    });
    onClose();
  };

  const handleSubmit = () => {
    onUpdate({
      ...bid,
      status: BidStatus.SUBMITTED,
      submissionDate: new Date().toISOString().split('T')[0]
    });
    onClose();
  };

  const vendorQuotes = bid.technicalDocuments.filter(d => d.vendorName || d.type === 'Quotation');

  return (
    <div className="flex flex-col h-screen bg-slate-50 relative">
      <input type="file" ref={technicalFileInputRef} onChange={(e) => handleFileUpload(e, 'Technical')} className="hidden" accept=".pdf" />
      <input type="file" ref={pricingFileInputRef} onChange={(e) => handleFileUpload(e, 'Financial')} className="hidden" accept=".pdf" />
      <input type="file" ref={complianceFileInputRef} onChange={(e) => handleFileUpload(e, 'Compliance')} className="hidden" accept=".pdf" />

      <div className="bg-[#1E3A5F] text-white p-4 flex items-center justify-between shadow-lg z-20">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h2 className="text-lg font-bold truncate max-w-md">{bid.projectName}</h2>
            <div className="flex items-center gap-3 text-[10px] text-slate-300 font-semibold uppercase tracking-wider">
              <span>Customer: {bid.customerName}</span>
              <span className="w-1 h-1 bg-white/30 rounded-full"></span>
              <span className="text-[#FFC107]">Deadline: {bid.deadline || 'NOT SET'}</span>
              <span className="w-1 h-1 bg-white/30 rounded-full"></span>
              <span className={remainingDays < 5 && remainingDays >= 0 ? "text-red-400 font-black animate-pulse" : remainingDays < 0 ? "text-red-600 font-black" : "text-emerald-400 font-black"}>
                {remainingDays < 0 ? "OVERDUE" : `REMAINING: ${remainingDays} DAYS`}
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-xs font-bold px-3 py-1 bg-white/10 rounded-full border border-white/20">
            JBC: {bid.jbcName}
          </span>
          <button onClick={() => setShowNoBidModal(true)} className="flex items-center gap-1 text-xs font-bold px-3 py-1 bg-red-600 hover:bg-red-700 rounded-full transition-colors">
            <ShieldAlert size={14} /> Mark No-Bid
          </button>
        </div>
      </div>

      <div className="bg-white border-b border-slate-200 px-8 py-6 shadow-sm z-10">
        <div className="flex items-center justify-between max-w-6xl mx-auto">
          {stagesOrder.map((stage, idx) => {
            const isCompleted = stagesOrder.indexOf(bid.currentStage) > idx;
            const isCurrent = activeStage === stage;
            return (
              <React.Fragment key={stage}>
                <button onClick={() => setActiveStage(stage)} className="flex flex-col items-center gap-2 group relative">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                    isCurrent ? "bg-[#D32F2F] border-[#D32F2F] text-white scale-110 shadow-lg" :
                    isCompleted ? "bg-emerald-500 border-emerald-500 text-white" :
                    "bg-white border-slate-200 text-slate-400 hover:border-slate-400"
                  }`}>
                    {STAGE_ICONS[stage]}
                  </div>
                  <span className={`text-[10px] font-bold uppercase tracking-tighter transition-colors ${isCurrent ? "text-slate-900" : "text-slate-400"}`}>
                    {stage}
                  </span>
                  {isCurrent && <div className="absolute -bottom-6 w-1.5 h-1.5 bg-[#D32F2F] rounded-full"></div>}
                </button>
                {idx < stagesOrder.length - 1 && (
                  <div className={`flex-1 h-[2px] mx-4 rounded-full transition-colors ${isCompleted ? "bg-emerald-500" : "bg-slate-200"}`}></div>
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-8 space-y-8 pb-32">
        <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8 max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <Info size={16} className="text-blue-500" /> Bid Brief & Scope
            </h3>
            <div className="flex gap-2">
              {bid.requiredSolutions.map(s => (
                <span key={s} className="px-3 py-1 bg-red-50 text-[#D32F2F] border border-red-100 rounded-full text-[10px] font-bold">
                  {s}
                </span>
              ))}
            </div>
          </div>
          <div className="space-y-4">
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
              <span className="text-[10px] font-black text-slate-400 uppercase mb-2 block">Project Summary</span>
              <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-line">
                {bid.summaryRequirements || "No summary requirements available."}
              </p>
            </div>
            {bid.scopeOfWork && (
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                <span className="text-[10px] font-black text-slate-400 uppercase mb-2 block">Scope of Work</span>
                <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-line">
                  {bid.scopeOfWork}
                </p>
              </div>
            )}
          </div>
        </section>

        <div className="max-w-6xl mx-auto space-y-8">
          {activeStage === BidStage.INTAKE && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-4">
              <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">Intake Submission Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Estimated Value</span>
                    <div className="text-lg font-bold text-slate-900">{bid.currency} {bid.estimatedValue.toLocaleString()}</div>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Bid Security</span>
                    <div className="text-lg font-bold text-slate-900">{bid.bidSecurity}</div>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Contract Duration</span>
                    <div className="text-lg font-bold text-slate-900">{bid.contractDuration || 'Not Specified'}</div>
                  </div>
                </div>
                <StageDocuments documents={bid.technicalDocuments.filter(d => d.type === 'Original Bid' || d.type === 'Tender Document')} title="Original Tender Documents" />
              </section>
            </div>
          )}

          {activeStage === BidStage.QUALIFICATION && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-4">
              <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8 border-l-8 border-l-amber-400">
                <div className="flex items-center gap-2 mb-6 text-amber-600">
                  <ShieldCheck size={24} />
                  <h3 className="text-lg font-bold uppercase tracking-widest">Mandatory Technical Eligibility</h3>
                </div>
                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 text-sm text-slate-700 whitespace-pre-line leading-relaxed italic">
                  {bid.qualificationCriteria || "No mandatory technical criteria extracted."}
                </div>
              </section>

              <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8 border-l-8 border-l-blue-400">
                <div className="flex items-center gap-2 mb-8 text-blue-600">
                  <CheckSquare size={24} />
                  <h3 className="text-lg font-bold uppercase tracking-widest">Compliance Checklist</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {bid.complianceChecklist.map((item, i) => (
                    <div key={i} className="flex flex-col p-5 bg-slate-50 rounded-2xl border border-slate-100 hover:border-blue-200 transition-all shadow-sm">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 rounded border-2 border-slate-300 flex items-center justify-center bg-white shadow-inner">
                             {item.status === 'Verified' && <CheckCircle2 size={16} className="text-emerald-500" />}
                          </div>
                          <span className="text-sm font-bold text-slate-900">{item.requirement}</span>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${
                          item.status === 'Pending' ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"
                        }`}>
                          {item.status}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 leading-relaxed bg-white/60 p-3 rounded-lg border border-slate-100 italic">
                        {item.aiComment}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
              <StageDocuments documents={bid.technicalDocuments.filter(d => d.category === 'Compliance')} title="Compliance Evidence Files" />
            </div>
          )}

          {activeStage === BidStage.SOLUTIONING && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-4">
              <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8">
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Solutioning & Tech Assessment</h3>
                  <div>
                    <button disabled={isAnalyzing} onClick={() => technicalFileInputRef.current?.click()} className="flex items-center gap-2 px-6 py-3 bg-[#D32F2F] text-white text-xs font-bold rounded-xl hover:bg-red-700 transition-all disabled:opacity-50">
                      {isAnalyzing ? <Loader2 size={16} className="animate-spin" /> : <FileUp size={16} />} 
                      Upload Technical Proposal
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                  <div className="lg:col-span-2 space-y-4">
                    {bid.technicalDocuments.filter(d => d.category === 'Technical').map(doc => (
                      <DocumentCard key={doc.id} doc={doc} showAnalysis={true} />
                    ))}
                  </div>
                  <div className="bg-slate-900 rounded-3xl p-8 text-white relative flex flex-col justify-center h-fit">
                    <Zap className="text-amber-400 mb-4" size={32} />
                    <h4 className="text-2xl font-black mb-1">
                      {bid.technicalDocuments.filter(d => d.category === 'Technical').length > 0 ? "88" : "0"}<span className="text-slate-500">/100</span>
                    </h4>
                    <p className="text-[10px] font-bold uppercase text-slate-400">AI Tech Alignment Score</p>
                  </div>
                </div>
                <StageDocuments documents={bid.technicalDocuments.filter(d => d.category === 'Technical')} title="Solution Design Documents" hideAnalysis={true} />
              </section>
            </div>
          )}

          {activeStage === BidStage.PRICING && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-4">
              <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                   <Zap size={16} className="text-amber-500" /> Vendor Quotes Summary
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {vendorQuotes.length > 0 ? vendorQuotes.map(quote => (
                    <div key={quote.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex flex-col gap-2">
                       <div className="flex justify-between items-center">
                         <span className="text-sm font-black text-slate-900">{quote.vendorName || "Unknown Vendor"}</span>
                         <span className="text-[10px] font-bold text-[#D32F2F] uppercase bg-red-50 px-2 py-0.5 rounded">{bid.currency}</span>
                       </div>
                       <div className="grid grid-cols-2 gap-2 text-[10px] font-medium text-slate-500">
                         <div>Validity: <span className="text-slate-700">{quote.validity || 'N/A'}</span></div>
                         <div>Terms: <span className="text-slate-700">{quote.paymentTerms || 'N/A'}</span></div>
                       </div>
                    </div>
                  )) : (
                    <div className="col-span-2 py-6 text-center text-xs text-slate-400 bg-slate-50 rounded-xl italic">
                      No vendor quotations found from solutioning stage.
                    </div>
                  )}
                </div>
              </section>

              <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8">
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Pricing Proposal Analysis</h3>
                  <div>
                    <button disabled={isAnalyzing} onClick={() => pricingFileInputRef.current?.click()} className="flex items-center gap-2 px-6 py-3 bg-[#D32F2F] text-white text-xs font-bold rounded-xl hover:bg-red-700 transition-all shadow-lg">
                      {isAnalyzing ? <Loader2 size={16} className="animate-spin" /> : <CreditCard size={16} />} 
                      Upload Pricing Proposal
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
                  <div className="bg-slate-900 text-white p-6 rounded-3xl shadow-xl flex flex-col justify-center">
                    <span className="text-[10px] font-bold text-slate-400 uppercase mb-1">TCV (Excl. Tax)</span>
                    <div className="text-2xl font-black">{bid.currency} {bid.tcvExclTax?.toLocaleString() || "0"}</div>
                  </div>
                  <div className="bg-blue-600 text-white p-6 rounded-3xl shadow-xl flex flex-col justify-center">
                    <span className="text-[10px] font-bold text-blue-100 uppercase mb-1">TCV (Incl. Tax)</span>
                    <div className="text-2xl font-black">{bid.currency} {bid.tcvInclTax?.toLocaleString() || "0"}</div>
                  </div>
                  <div className="bg-slate-50 border border-slate-100 p-6 rounded-3xl flex flex-col justify-center">
                    <span className="text-[10px] font-bold text-slate-400 uppercase mb-1">Contract Duration</span>
                    <div className="text-xl font-black text-slate-800">{bid.contractDuration || "N/A"}</div>
                  </div>
                  <div className="bg-red-50 border border-red-100 p-6 rounded-3xl flex flex-col justify-center">
                    <span className="text-[10px] font-bold text-red-400 uppercase mb-1">Payment Terms</span>
                    <div className="text-xl font-black text-[#D32F2F]">{bid.customerPaymentTerms ? `${bid.customerPaymentTerms} Days` : "N/A"}</div>
                  </div>
                </div>

                <div className="mb-10">
                  <h4 className="text-xs font-bold text-slate-500 uppercase mb-6 flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-blue-500" /> Financial Format (UX Optimized)
                  </h4>
                  <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
                    <table className="w-full text-left text-sm">
                      <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                        <tr>
                          <th className="px-6 py-4">Item & Description</th>
                          <th className="px-6 py-4">UOM</th>
                          <th className="px-6 py-4 text-center">Qty</th>
                          <th className="px-6 py-4 text-right">Unit Rate</th>
                          <th className="px-6 py-4 text-right">Total Price ({bid.currency})</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {bid.financialFormats.length > 0 ? bid.financialFormats.map((f, i) => (
                          <tr key={i} className="hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 font-medium text-slate-900">{f.item}</td>
                            <td className="px-6 py-4 text-slate-500">{f.uom}</td>
                            <td className="px-6 py-4 text-center text-slate-700">{f.quantity}</td>
                            <td className="px-6 py-4 text-right font-semibold">{f.unitPrice?.toLocaleString() || '-'}</td>
                            <td className="px-6 py-4 text-right font-black text-[#D32F2F]">{f.totalPrice?.toLocaleString() || '-'}</td>
                          </tr>
                        )) : (
                          <tr>
                            <td colSpan={5} className="px-6 py-10 text-center text-slate-400 italic">No financial format extracted from intake.</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
                <StageDocuments documents={bid.technicalDocuments.filter(d => d.category === 'Financial')} title="Pricing Proposals" hideAnalysis={true} />
              </section>

              <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8">
                 <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                    <UserCheck size={16} className="text-blue-500" /> Management Approvals Workflow
                 </h3>
                 <div className="flex flex-col md:flex-row items-center gap-8">
                    <div className={`px-6 py-4 rounded-2xl border-2 flex items-center gap-3 flex-1 ${
                      bid.managementApprovalStatus === 'Approved' ? "bg-emerald-50 border-emerald-200 text-emerald-800" :
                      bid.managementApprovalStatus === 'Pending' ? "bg-amber-50 border-amber-200 text-amber-800" :
                      bid.managementApprovalStatus === 'Not Required' ? "bg-slate-50 border-slate-200 text-slate-500" :
                      "bg-white border-slate-100 text-slate-400"
                    }`}>
                       <div className={`p-2 rounded-full ${
                         bid.managementApprovalStatus === 'Approved' ? "bg-emerald-500" : 
                         bid.managementApprovalStatus === 'Pending' ? "bg-amber-500" : 
                         "bg-slate-400"
                        } text-white`}>
                         {bid.managementApprovalStatus === 'Approved' ? <CheckCircle2 size={16} /> : <Clock size={16} />}
                       </div>
                       <div>
                         <span className="text-[10px] font-black uppercase block opacity-70">Current Status</span>
                         <span className="text-lg font-bold">{bid.managementApprovalStatus || 'Not Set'}</span>
                       </div>
                    </div>
                    <div className="flex bg-slate-100 p-1 rounded-2xl border border-slate-200">
                       {(['Not Required', 'Pending', 'Approved'] as const).map((status) => (
                         <button
                           key={status}
                           onClick={() => onUpdate({ ...bid, managementApprovalStatus: status })}
                           className={`px-6 py-3 rounded-xl text-xs font-bold transition-all ${
                             bid.managementApprovalStatus === status
                               ? "bg-white text-slate-900 shadow-md translate-y-0"
                               : "text-slate-500 hover:text-slate-700"
                           }`}
                         >
                           {status}
                         </button>
                       ))}
                    </div>
                 </div>
              </section>
            </div>
          )}

          {activeStage === BidStage.COMPLIANCE && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-4">
              <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8 border-l-8 border-l-[#D32F2F]">
                <div className="flex items-center justify-between mb-10">
                  <div className="flex items-center gap-2 text-slate-900">
                    <Sparkles className="text-[#D32F2F]" size={24} />
                    <h3 className="text-lg font-bold uppercase tracking-widest">AI Qualification Criteria</h3>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-3">
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Assessment:</span>
                      <span className={`px-4 py-1.5 rounded-full text-xs font-black border uppercase tracking-wider ${
                        bid.aiQualificationAssessment === 'Go' ? "bg-emerald-50 text-emerald-600 border-emerald-100" :
                        bid.aiQualificationAssessment === 'No-Go' ? "bg-red-50 text-red-600 border-red-100" :
                        "bg-amber-50 text-amber-600 border-amber-100"
                      }`}>
                        {bid.aiQualificationAssessment || 'Needs Review'}
                      </span>
                    </div>
                    <div className="h-4 w-px bg-slate-200"></div>
                    <div className="flex items-center gap-3">
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Confidence:</span>
                      <span className="text-sm font-black text-[#D32F2F]">{bid.aiConfidenceScore || '0'}%</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-10">
                  <div className="space-y-6">
                    <div>
                      <h4 className="text-[10px] font-black text-emerald-600 uppercase tracking-widest flex items-center gap-2 mb-4">
                         <CheckCircle2 size={14} /> Key Qualifying Factors
                      </h4>
                      {bid.qualifyingFactors && bid.qualifyingFactors.length > 0 ? (
                        <ul className="space-y-3">
                          {bid.qualifyingFactors.map((f, i) => (
                            <li key={i} className="text-sm text-slate-600 flex items-start gap-3">
                              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 flex-shrink-0"></div>
                              <span>{f}</span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-sm text-slate-400 italic">No qualifying factors identified yet.</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <h4 className="text-[10px] font-black text-red-500 uppercase tracking-widest flex items-center gap-2 mb-4">
                         <XCircle size={14} /> Disqualifying Factors
                      </h4>
                      {bid.disqualifyingFactors && bid.disqualifyingFactors.length > 0 ? (
                        <ul className="space-y-3">
                          {bid.disqualifyingFactors.map((f, i) => (
                            <li key={i} className="text-sm text-slate-600 flex items-start gap-3">
                              <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-2 flex-shrink-0"></div>
                              <span>{f}</span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-sm text-emerald-500 font-medium flex items-center gap-2">
                           <CheckCircle2 size={14} /> No major disqualifying factors found.
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="pt-8 border-t border-slate-100 flex justify-center">
                  <button 
                    disabled={isAnalyzing} 
                    onClick={() => complianceFileInputRef.current?.click()} 
                    className="flex items-center gap-3 px-10 py-4 bg-blue-600 text-white text-sm font-bold rounded-2xl hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 disabled:opacity-50"
                  >
                    {isAnalyzing ? <Loader2 size={18} className="animate-spin" /> : <FileUp size={18} />} 
                    Upload Compliance & Bid Docs
                  </button>
                </div>
              </section>

              <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8 border-l-8 border-l-blue-400">
                <div className="flex items-center gap-2 mb-10 text-blue-600">
                  <CheckSquare size={24} />
                  <h3 className="text-lg font-bold uppercase tracking-widest">Compliance & Eligibility Checklist</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {bid.complianceChecklist.length > 0 ? bid.complianceChecklist.map((item, i) => (
                    <div key={i} className="flex flex-col p-6 bg-slate-50 rounded-2xl border border-slate-100 hover:border-blue-200 transition-all shadow-sm group">
                      <div className="flex items-center justify-between mb-4">
                        <button 
                          onClick={() => toggleComplianceStatus(i)}
                          className="flex items-center gap-3 text-left focus:outline-none group/checkbox"
                        >
                          <div className={`w-6 h-6 rounded border-2 flex items-center justify-center bg-white shadow-inner transition-colors ${item.status === 'Verified' ? "border-emerald-300 bg-emerald-50" : "border-slate-300 group-hover/checkbox:border-blue-400"}`}>
                             {item.status === 'Verified' && <CheckCircle2 size={16} className="text-emerald-500" />}
                          </div>
                          <span className="text-sm font-bold text-slate-900 group-hover/checkbox:text-blue-600 transition-colors">{item.requirement}</span>
                        </button>
                        <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-wider ${
                          item.status === 'Pending' ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"
                        }`}>
                          {item.status === 'Verified' ? 'Complete' : item.status}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 leading-relaxed bg-white/60 p-4 rounded-xl border border-slate-100 italic">
                        {item.aiComment || "Extracted from tender requirements document. Documentation required for verification."}
                      </div>
                    </div>
                  )) : (
                    <div className="col-span-2 py-16 text-center text-xs text-slate-400 italic bg-slate-50 rounded-3xl border border-dashed border-slate-200">
                      No compliance items auto-generated. Please ensure the tender document was analyzed correctly during intake.
                    </div>
                  )}
                </div>
                <StageDocuments documents={bid.technicalDocuments.filter(d => d.category === 'Compliance')} title="Compliance Evidence Files" hideAnalysis={true} />
              </section>
            </div>
          )}

          {activeStage === BidStage.FINAL_REVIEW && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-4">
              <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">Final Package Review</h3>
                <div className="space-y-6">
                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                    <h4 className="text-xs font-bold text-slate-500 uppercase mb-4">Consolidated Bid Repository</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {bid.technicalDocuments.map(doc => (
                        <DocumentCard key={doc.id} doc={doc} showAnalysis={true} />
                      ))}
                      {bid.technicalDocuments.length === 0 && (
                        <p className="col-span-2 text-center text-xs text-slate-400 py-6 italic">No documents uploaded throughout the lifecycle.</p>
                      )}
                    </div>
                  </div>
                </div>
              </section>

              <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-12 text-center max-w-2xl mx-auto shadow-xl">
                <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
                  <CheckCircle2 size={56} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Ready for Submission</h3>
                <p className="text-slate-500 text-sm mb-10 leading-relaxed text-center">All mandatory stages have been reviewed. AI Accuracy Score is verified.</p>
                <button onClick={handleSubmit} className="w-full bg-[#D32F2F] text-white py-5 rounded-2xl font-bold shadow-2xl shadow-red-200 hover:bg-[#B71C1C] transition-all transform active:scale-95 text-lg">
                  Submit Final Bid
                </button>
              </section>
            </div>
          )}
        </div>
      </div>

      <FloatingAIChat bid={bid} />

      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[30]">
        <div className="bg-white/90 backdrop-blur-md border border-slate-200 p-2 rounded-2xl shadow-2xl flex items-center gap-2">
           <button onClick={() => moveStage(-1)} disabled={currentStageIndex === 0} className="p-3 bg-white text-slate-600 rounded-xl hover:bg-slate-50 disabled:opacity-30 border border-slate-100 transition-all">
             <ChevronLeft size={20} />
           </button>
           <div className="px-6 flex flex-col items-center">
              <span className="text-[10px] font-black text-slate-400 uppercase">Current Step</span>
              <span className="text-sm font-bold text-slate-900">{activeStage}</span>
           </div>
           <button onClick={() => moveStage(1)} disabled={currentStageIndex === stagesOrder.length - 1} className="p-3 bg-[#D32F2F] text-white rounded-xl hover:bg-red-700 disabled:opacity-30 transition-all shadow-lg">
             <ChevronRight size={20} />
           </button>
        </div>
      </div>

      {showNoBidModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-[40px] w-full max-w-md p-10 animate-in zoom-in-95 duration-200 shadow-2xl">
            <h3 className="text-2xl font-bold text-slate-900 mb-2 text-center">Mark as No-Bid?</h3>
            <p className="text-sm text-slate-500 mb-8 text-center leading-relaxed">Please provide a reason for cancelling this bid opportunity.</p>
            <textarea value={noBidReason} onChange={e => setNoBidReason(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 text-sm focus:ring-2 focus:ring-red-500 focus:outline-none mb-8" placeholder="Reason for decision..." rows={4} />
            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => setShowNoBidModal(false)} className="py-4 rounded-2xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 transition-all">Cancel</button>
              <button onClick={markNoBid} className="py-4 rounded-2xl bg-red-600 text-white font-bold hover:bg-red-700 shadow-xl shadow-red-100 transition-all">Confirm</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const StageDocuments: React.FC<{ documents: TechnicalDocument[], title?: string, hideAnalysis?: boolean }> = ({ documents, title = "Uploaded Phase Documents", hideAnalysis = false }) => {
  if (documents.length === 0) return null;
  return (
    <div className="mt-8 border-t border-slate-100 pt-8">
      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
        <FileText size={16} className="text-slate-400" /> {title}
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {documents.map(doc => (
          <DocumentCard key={doc.id} doc={doc} showAnalysis={!hideAnalysis} />
        ))}
      </div>
    </div>
  );
};

const DocumentCard: React.FC<{ doc: TechnicalDocument; showAnalysis?: boolean }> = ({ doc, showAnalysis = true }) => (
  <div className="bg-white p-5 rounded-2xl border border-slate-200 group hover:border-[#D32F2F] transition-all shadow-sm">
    <div className="flex justify-between items-start mb-3">
       <div className="flex items-center gap-3 min-w-0">
         <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 shadow-sm border border-slate-100 group-hover:bg-red-50 group-hover:text-[#D32F2F] transition-colors shrink-0">
           <FileText size={20} />
         </div>
         <div className="min-w-0">
           <h5 className="text-xs font-bold text-slate-900 truncate pr-2" title={doc.name}>{doc.name}</h5>
           <p className="text-[9px] text-slate-400 font-medium uppercase tracking-wider">{doc.type} • {doc.uploadDate}</p>
         </div>
       </div>
       <div className="flex items-center gap-2 shrink-0">
         {doc.aiScore !== undefined && (
            <div className="bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded-full text-[9px] font-black border border-emerald-100">
              {doc.aiScore}/100
            </div>
         )}
         <button className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all" title="Download Document">
           <Download size={14} />
         </button>
       </div>
    </div>
    {showAnalysis && doc.aiMatchDetails && (
      <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 mt-1">
        <span className="text-[8px] font-black text-slate-400 uppercase mb-1 block">AI Analysis</span>
        <p className="text-[11px] text-slate-600 leading-relaxed whitespace-pre-line">
          {doc.aiMatchDetails}
        </p>
      </div>
    )}
  </div>
);

export default BidLifecycle;