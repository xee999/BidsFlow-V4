export enum BidStage {
  INTAKE = 'Intake',
  QUALIFICATION = 'Qualification',
  SOLUTIONING = 'Solutioning',
  PRICING = 'Pricing',
  COMPLIANCE = 'Compliance',
  FINAL_REVIEW = 'Final Review'
}

export enum BidStatus {
  ACTIVE = 'Active',
  SUBMITTED = 'Submitted',
  WON = 'Won',
  LOST = 'Lost',
  NO_BID = 'No Bid'
}

export enum RiskLevel {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High'
}

export interface FinancialFormat {
  item: string;
  description: string;
  uom: string;
  quantity: number;
  unitPrice?: number;
  totalPrice?: number;
}

export interface ComplianceItem {
  requirement: string;
  status: 'Pending' | 'Uploaded' | 'Missing' | 'Verified';
  documentName?: string;
  aiComment?: string;
  aiScore?: number;
}

export interface TechnicalDocument {
  id: string;
  name: string;
  type: string; // MAF, MAL, Specs, OEM Letter, Quotation, etc.
  category: 'Technical' | 'Financial' | 'Compliance';
  uploadDate: string;
  aiScore?: number;
  aiMatchDetails?: string;
  vendorName?: string;
  validity?: string;
  currency?: 'PKR' | 'USD';
  paymentTerms?: string;
}

export interface StageTransition {
  stage: BidStage;
  timestamp: string;
}

export interface BidRecord {
  id: string;
  customerName: string;
  projectName: string;
  deadline: string;
  receivedDate: string;
  status: BidStatus;
  currentStage: BidStage;
  riskLevel: RiskLevel;
  estimatedValue: number;
  currency: string;
  bidSecurity: string;
  requiredSolutions: string[];
  summaryRequirements: string;
  scopeOfWork: string;
  qualificationCriteria: string;
  complianceChecklist: ComplianceItem[];
  technicalDocuments: TechnicalDocument[];
  vendorQuotations: TechnicalDocument[];
  financialFormats: FinancialFormat[];
  noBidReason?: string;
  noBidStage?: string;
  daysInStages: Record<string, number>;
  stageHistory: StageTransition[];
  submissionDate?: string;
  aiQualificationScore?: number;
  jbcName: string;
  // New Financial Fields
  contractDuration?: string;
  customerPaymentTerms?: string;
  tcvExclTax?: number;
  tcvInclTax?: number;
  managementApprovalStatus?: 'Not Required' | 'Pending' | 'Approved';
  // New Qualification Assessment Fields
  aiQualificationAssessment?: 'Go' | 'No-Go' | 'Needs Review';
  qualifyingFactors?: string[];
  disqualifyingFactors?: string[];
  aiConfidenceScore?: number;
}

export interface User {
  id: string;
  name: string;
  role: 'BidsTeam' | 'Sales' | 'Management' | 'Technical';
}