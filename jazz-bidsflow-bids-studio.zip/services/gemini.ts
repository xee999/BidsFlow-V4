import { GoogleGenAI, Type } from "@google/genai";

export const analyzeBidDocument = async (fileName: string, fileContentBase64: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { data: fileContentBase64, mimeType: 'application/pdf' } },
          { text: "Analyze this tender/bid document for a Jazz Business (Telecom) submission.\n\nMANDATORY EXTRACTION RULES:\n1. Submission Deadline: Format as YYYY-MM-DD. Search carefully for 'submission date', 'closing date', or 'deadline'.\n2. Payment Terms: Extract the number of days ONLY (e.g. '45').\n3. Contract Duration: Format like '2 Years' or '36 Months'.\n4. Estimated Value & Security: Extract raw numeric values if present.\n5. Project Summary: A concise 2-3 sentence overview.\n6. Scope of Work: A detailed technical breakdown of requirements.\n7. Required Solutions: Identify which categories apply from: Quantica, GSM Data, M2M (Devices Only), IoT, IT Devices (Laptop/Desktop), Mobile Devices (Phone or Tablet), CPaaS, Cloud Solutions, Fixed Connectivity.\n8. Qualification & Compliance: Extract ALL technical qualification criteria (e.g., specific certifications, mandatory years of experience, past project requirements) AND administrative compliance requirements (e.g., tax documents, registration, affidavits) as individual checklist items." }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            customerName: { type: Type.STRING },
            projectName: { type: Type.STRING },
            deadline: { type: Type.STRING },
            estimatedValue: { type: Type.NUMBER },
            currency: { type: Type.STRING },
            bidSecurity: { type: Type.STRING },
            qualificationCriteria: { type: Type.STRING },
            summaryRequirements: { type: Type.STRING },
            scopeOfWork: { type: Type.STRING },
            contractDuration: { type: Type.STRING },
            customerPaymentTerms: { type: Type.STRING },
            requiredSolutions: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING }
            },
            financialFormats: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  item: { type: Type.STRING },
                  description: { type: Type.STRING },
                  uom: { type: Type.STRING },
                  quantity: { type: Type.NUMBER }
                }
              }
            },
            complianceList: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  requirement: { type: Type.STRING, description: "Short name of the requirement (e.g. ISO 27001, 5 Years ISP Experience, NTN Certificate)" },
                  description: { type: Type.STRING, description: "Detailed description of the requirement from the document." }
                },
                required: ["requirement", "description"]
              },
              description: "Must include both technical qualification criteria and administrative compliance items."
            }
          }
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("AI Analysis failed:", error);
    return null;
  }
};

export const analyzePricingDocument = async (fileContentBase64: string, contractDuration: string, financialFormat: any[]) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { data: fileContentBase64, mimeType: 'application/pdf' } },
          { text: `Analyze this pricing proposal. 
            1. Calculate TCV Excluding Tax: SUM(unit_price * quantity) * duration (${contractDuration}). 
            2. Calculate TCV Including Tax: TCV_Excl_Tax + applicable taxes.
            3. Fill out the specific items in the financial format provided: ${JSON.stringify(financialFormat)}.` }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tcvExclTax: { type: Type.NUMBER },
            tcvInclTax: { type: Type.NUMBER },
            populatedFinancialFormat: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  item: { type: Type.STRING },
                  unitPrice: { type: Type.NUMBER },
                  totalPrice: { type: Type.NUMBER }
                }
              }
            }
          },
          required: ["tcvExclTax", "tcvInclTax", "populatedFinancialFormat"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Pricing Analysis failed:", error);
    return null;
  }
};

export const compareTechnicalSolution = async (tenderRequirements: string, solutionBase64: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { data: solutionBase64, mimeType: 'application/pdf' } },
          { text: `Compare this uploaded Technical Solution document against the following Tender Requirements: "${tenderRequirements}". Evaluate compliance and completeness.` }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            aiScore: { type: Type.NUMBER },
            matchDetails: { type: Type.STRING },
            lackingDetails: { type: Type.STRING },
            vendorName: { type: Type.STRING },
            validity: { type: Type.STRING },
            currency: { type: Type.STRING },
            paymentTerms: { type: Type.STRING }
          },
          required: ["aiScore", "matchDetails", "lackingDetails"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Technical Comparison failed:", error);
    return null;
  }
};

export const analyzeComplianceDocuments = async (tenderRequirements: string, complianceChecklist: any[], docBase64: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { data: docBase64, mimeType: 'application/pdf' } },
          { text: `Analyze the uploaded compliance and bid documents against the tender requirements: "${tenderRequirements}". 
            1. Update the status of the checklist items: ${JSON.stringify(complianceChecklist)}.
            2. Re-evaluate the Overall Assessment (Go/No-Go/Needs Review).
            3. Provide updated Key Qualifying Factors (3-5 items).
            4. Identify any Disqualifying Factors.
            5. Provide an AI Confidence Score (0-100).` }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            updatedChecklist: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  requirement: { type: Type.STRING },
                  status: { type: Type.STRING, description: "Must be 'Verified' or 'Pending'" },
                  aiComment: { type: Type.STRING }
                },
                required: ["requirement", "status", "aiComment"]
              }
            },
            assessment: { type: Type.STRING },
            qualifyingFactors: { type: Type.ARRAY, items: { type: Type.STRING } },
            disqualifyingFactors: { type: Type.ARRAY, items: { type: Type.STRING } },
            confidenceScore: { type: Type.NUMBER }
          },
          required: ["updatedChecklist", "assessment", "qualifyingFactors", "confidenceScore"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Compliance Analysis failed:", error);
    return null;
  }
};

export const chatWithBidAssistant = async (question: string, context: any) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const chatResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Context: ${JSON.stringify(context)}. Question: ${question}. Provide a brief 2-3 line answer strictly based on the provided context. If unsure, say you don't know.`
    });
    return chatResponse.text;
  } catch (err) {
    return "I'm sorry, I'm having trouble accessing the bid details right now.";
  }
};